// Optional: stub for chart logic with Chart.js or similar
window.onload = async function () {
  // Placeholder: fetch history
  const res = await fetch('/history');
  const history = await res.json();
  if (!history.length) return;
  const ctx = document.getElementById('chart').getContext('2d');
  // If using Chart.js, implement chart here.
  ctx.fillText('History Loaded: ' + JSON.stringify(history), 10, 10);
};